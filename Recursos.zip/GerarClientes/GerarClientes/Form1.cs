using Newtonsoft.Json;
using System.Diagnostics;
using System.Security.Policy;
using System.Text;

namespace GerarClientes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GerarScriptButton_Click(object sender, EventArgs e)
        {
            try
            {
                ScriptGeradoTextBox.Text = string.Empty;

                var jsonText = JsonTextBox.Text;

                if (string.IsNullOrWhiteSpace(jsonText))
                    throw new Exception("Informe o JSON");

                dynamic pessoas = JsonConvert.DeserializeObject(jsonText);

                var stbQuery = new StringBuilder();

                foreach (var pessoa in pessoas)
                {
                    var rndSexo = new Random().Next(1, 2);
                    var rndEstadoCivil = new Random().Next(1, 3);
                    var rndOrgaoExpedicao = new Random().Next(1, 2);

                    var strIdade = Convert.ToString(pessoa["idade"]);

                    var idade = int.Parse(strIdade);
                    var rndDiaNascimento = new Random().Next(1, 365);

                    var anoNascimento = DateTime.Now.Year - idade;

                    var dtNascimento = new DateTime(anoNascimento - 1, 12, 31).AddDays(rndDiaNascimento);

                    var rndDiaExpedicao = new Random().Next(1, 365);
                    var dtExpedicaoDocumento = dtNascimento.AddDays(rndDiaExpedicao);

                    stbQuery.AppendLine($"INSERT INTO ENDERECO VALUES ('{pessoa["cep"]}', '{pessoa["endereco"]}', '{pessoa["numero"]}', '', '{pessoa["bairro"]}', '{pessoa["cidade"]}', '{pessoa["estado"]}')");
                    stbQuery.AppendLine($"INSERT INTO CLIENTE VALUES('{pessoa["cpf"]}', '{pessoa["nome"]}', '{pessoa["rg"]}', '{dtNascimento.ToString("yyyy-MM-dd")}', {rndOrgaoExpedicao}, '{pessoa["estado"]}', '{dtExpedicaoDocumento.ToString("yyyy-MM-dd")}', {rndSexo}, {rndEstadoCivil}, (SELECT @@IDENTITY))");
                    stbQuery.AppendLine(Environment.NewLine);
                }

                ScriptGeradoTextBox.Text = stbQuery.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var url = "https://www.4devs.com.br/gerador_de_pessoas";
            Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
        }
    }
}