USE MASTER
DROP DATABASE ClienteCRUDDB
--
CREATE DATABASE ClienteCRUDDB

USE CLIENTECRUDDB


CREATE TABLE ORGAOEXPEDICAO
(
	Id INT IDENTITY PRIMARY KEY NOT NULL,
	Descricao VARCHAR(100)
)

CREATE TABLE SEXO
(
	Id INT IDENTITY PRIMARY KEY NOT NULL,
	Descricao VARCHAR(100)
)

CREATE TABLE ESTADOCIVIL
(
	Id INT IDENTITY PRIMARY KEY NOT NULL,
	Descricao VARCHAR(100)
)

INSERT INTO ORGAOEXPEDICAO
VALUES ('SSP')

INSERT INTO ORGAOEXPEDICAO
VALUES ('CREA')

INSERT INTO SEXO
VALUES ('MASCULINO'),('FEMININO')

INSERT INTO ESTADOCIVIL
VALUES ('CASADO'),('SOLTEIRO'),('VIUVO')

CREATE TABLE ENDERECO
(
	Id INT IDENTITY PRIMARY KEY NOT NULL,
	CEP VARCHAR(8) NOT NULL,
	Rua VARCHAR(100) NOT NULL,
	Numero VARCHAR(20) NOT NULL,
	Complemento VARCHAR(100),
	Bairro VARCHAR(100) NOT NULL,
	Cidade VARCHAR(100) NOT NULL,
	UF VARCHAR(2) NOT NULL
)


CREATE TABLE CLIENTE
(
	Id INT IDENTITY PRIMARY KEY NOT NULL,
	CPF VARCHAR(11) NOT NULL,
	Nome VARCHAR(100) NOT NULL,
	RG VARCHAR (15),
	DataExpedicao DATE,
	OrgaoExpedicaoId INT FOREIGN KEY REFERENCES ORGAOEXPEDICAO (Id),
	UFExpedicao VARCHAR(2),
	DataNascimento DATE NOT NULL,
	SexoId INT NOT NULL FOREIGN KEY REFERENCES SEXO(Id),
	EstadoCivilId INT NOT NULL FOREIGN KEY REFERENCES ESTADOCIVIL(Id),
	EnderecoId INT NOT NULL FOREIGN KEY REFERENCES ENDERECO (Id)
)


----------------------------------------------------------------------------------------------------------------------------------

DECLARE @IDCLIENTE INT = 1

SELECT 
	A.CPF,
	A.Nome,
	A.RG,
	CONVERT(VARCHAR, A.DataExpedicao, 103) AS DataExpedicao,
	A.UFExpedicao,
	D.Descricao AS OgaoExpedicao,
	CONVERT(VARCHAR, A.DataNascimento, 103) AS DataNascimento,
	E.Descricao AS Sexo,
	C.Descricao AS EstadoCivil,
	B.CEP,
	B.Rua,
	B.Numero,
	B.Complemento,
	B.Bairro,
	B.Cidade,
	B.UF
FROM CLIENTE A 
	INNER JOIN ENDERECO B ON A.EnderecoId = B.Id
	INNER JOIN ESTADOCIVIL C ON A.EstadoCivilId = C.Id
	INNER JOIN ORGAOEXPEDICAO D ON A.OrgaoExpedicaoId = D.Id
	INNER JOIN SEXO E ON A.SexoId = E.Id
WHERE A.ID = @IDCLIENTE
----------------------------------------------------------------------------------------------------------------------------------


SELECT * FROM CLIENTE  ORDER BY ID DESC
SELECT * FROM ENDERECO ORDER BY ID DESC
SELECT * FROM ESTADOCIVIL
SELECT * FROM ORGAOEXPEDICAO
SELECT * FROM SEXO


DELETE FROM CLIENTE
DELETE FROM ENDERECO


INSERT INTO ENDERECO VALUES ('81935720', 'Rua Pedro Luiz Scroccaro', '253', '', 'Ganchinho', 'Curitiba', 'PR')
INSERT INTO CLIENTE VALUES('80623588285', 'Vit�ria Emily Dias', '439071781', '1972-06-14', 1, 'PR', '1972-11-20', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('79902132', 'Rua Cuiab�', '112', '', 'Vila �urea', 'Ponta Por�', 'MS')
INSERT INTO CLIENTE VALUES('06549337585', 'Isadora Yasmin Figueiredo', '229515940', '2003-11-04', 1, 'MS', '2004-10-06', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69318140', 'Rua CC-29', '757', '', 'Senador H�lio Campos', 'Boa Vista', 'RR')
INSERT INTO CLIENTE VALUES('88932607788', 'Isaac Marcos Vinicius Moreira', '497331196', '2001-08-20', 1, 'RR', '2001-08-24', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('74988666', 'Rua Machado de Assis', '700', '', 'Nova Olinda - 2� Complemento', 'Aparecida de Goi�nia', 'GO')
INSERT INTO CLIENTE VALUES('62372857177', 'Gabriela Let�cia Jesus', '205448707', '1961-03-02', 1, 'GO', '1961-03-22', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('76909800', 'Rua Francisco Pereira dos Santos', '583', '', 'Nossa Senhora de F�tima', 'Ji-Paran�', 'RO')
INSERT INTO CLIENTE VALUES('12329966709', 'Valentina Stefany Malu Gomes', '369884012', '1961-05-27', 1, 'RO', '1962-04-14', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68928006', 'Avenida Princesa Izabel', '459', '', 'Para�so', 'Santana', 'AP')
INSERT INTO CLIENTE VALUES('08780383297', 'Vinicius Gabriel M�rio Sales', '410457097', '1988-05-14', 1, 'AP', '1988-10-13', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('25980330', 'Estrada Brejal', '627', '', 'Granja Mafra', 'Teres�polis', 'RJ')
INSERT INTO CLIENTE VALUES('39461066252', 'Raul Iago Nathan Pinto', '196859281', '1998-05-30', 1, 'RJ', '1998-09-03', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('33840412', 'Rua Cento e Vinte e Seis', '316', '', 'Sevilha (2� Se��o)', 'Ribeir�o das Neves', 'MG')
INSERT INTO CLIENTE VALUES('27091119266', 'Luana Emilly Caldeira', '373115040', '1962-07-17', 1, 'MG', '1962-08-20', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('88807623', 'Rua Jorge Al�ssio', '786', '', 'Sang�o', 'Crici�ma', 'SC')
INSERT INTO CLIENTE VALUES('58691020571', 'Luana Louise F�tima Galv�o', '499897961', '1956-06-14', 1, 'SC', '1957-03-01', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59074811', 'Travessa de M�e Luiza', '542', '', 'Guarapes', 'Natal', 'RN')
INSERT INTO CLIENTE VALUES('76198684377', 'Andr� Alexandre Thales Nascimento', '440564335', '1958-04-25', 1, 'RN', '1959-01-09', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('66113822', 'Vila Bordalo', '592', '', 'Tel�grafo Sem Fio', 'Bel�m', 'PA')
INSERT INTO CLIENTE VALUES('18793939647', 'Ros�ngela La�s Jaqueline Cavalcanti', '503569288', '1969-05-05', 1, 'PA', '1970-04-02', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('29163479', 'Rua Terceiro Mundo', '330', '', 'Cidade Continental-Setor �frica', 'Serra', 'ES')
INSERT INTO CLIENTE VALUES('32463494522', 'S�nia Aparecida Bernardes', '188730059', '1991-08-24', 1, 'ES', '1991-10-17', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69044785', 'Rua Viriato Ferreira', '331', '', 'Planalto', 'Manaus', 'AM')
INSERT INTO CLIENTE VALUES('60627205097', 'Milena Elo� Oliveira', '295338763', '1973-01-13', 1, 'AM', '1973-09-02', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('53637525', 'Avenida Bar�o de Vera Cruz', '304', '', 'Santa Luzia', 'Igarassu', 'PE')
INSERT INTO CLIENTE VALUES('48858869109', 'Heloisa Carolina Silvana Santos', '276754402', '1953-01-15', 1, 'PE', '1953-09-04', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('87013922', 'Pra�a Raposo Tavares 36', '453', '', 'Zona 01', 'Maring�', 'PR')
INSERT INTO CLIENTE VALUES('17300823866', 'Jennifer Sueli Aparecida Melo', '300120710', '1973-06-03', 1, 'PR', '1973-09-28', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('73368546', 'Quadra 19 Conjunto F', '372', '', 'Arapoanga (Planaltina)', 'Bras�lia', 'DF')
INSERT INTO CLIENTE VALUES('32795567164', 'Juan Tom�s Breno Alves', '405365652', '1967-10-01', 1, 'DF', '1968-04-13', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('40300100', 'Rua Alfredo Jos� dos Santos', '756', '', 'Baixa de Quintas', 'Salvador', 'BA')
INSERT INTO CLIENTE VALUES('54798555576', 'Tom�s Vicente Victor da Rocha', '304772100', '1961-06-07', 1, 'BA', '1961-11-28', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('77450970', 'Avenida C 596', '692', '', 'Setor Central', 'Ja� do Tocantins', 'TO')
INSERT INTO CLIENTE VALUES('79818171454', 'Hugo Guilherme Gon�alves', '402677936', '1980-10-10', 1, 'TO', '1981-05-08', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('58704030', 'Rua Beltrando de Azevedo', '583', '', 'Belo Horizonte', 'Patos', 'PB')
INSERT INTO CLIENTE VALUES('46700484731', 'Analu Alice Clara Arag�o', '264827326', '1968-03-10', 1, 'PB', '1968-10-06', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69912140', 'Rua S�o Batista', '869', '', 'Boa Vista', 'Rio Branco', 'AC')
INSERT INTO CLIENTE VALUES('21140420810', 'Ryan Renan Teixeira', '429185583', '1990-05-02', 1, 'AC', '1990-07-31', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69037087', 'Alameda Ge�rgia', '307', '', 'Ponta Negra', 'Manaus', 'AM')
INSERT INTO CLIENTE VALUES('53043214803', 'Isaac F�bio Jorge Farias', '369751966', '1956-08-01', 1, 'AM', '1956-12-30', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('60832146', 'Rua Santa Benedita da Cruz', '970', '', 'Lagoa Redonda', 'Fortaleza', 'CE')
INSERT INTO CLIENTE VALUES('91367540488', 'Melissa Rebeca Assis', '293666763', '2005-01-09', 1, 'CE', '2005-05-08', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('50711190', 'Rua Rubem Berta', '456', '', 'Cordeiro', 'Recife', 'PE')
INSERT INTO CLIENTE VALUES('18292706569', 'Jaqueline Nat�lia de Paula', '452557665', '1988-12-16', 1, 'PE', '1989-07-01', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('82030585', 'Parque Tingui', '139', '', 'S�o Jo�o', 'Curitiba', 'PR')
INSERT INTO CLIENTE VALUES('88013880397', 'Giovanna Renata Novaes', '145730050', '1956-07-09', 1, 'PR', '1957-05-26', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('79901242', 'Rua Crist�v�o Colombo', '340', '', 'Jardim Ivone 1� Se��o', 'Ponta Por�', 'MS')
INSERT INTO CLIENTE VALUES('50149778040', 'Eliane Nina Helena Carvalho', '297357700', '1943-01-11', 1, 'MS', '1943-09-22', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('66090330', 'Travessa Pracinha Maur�cio de Ara�jo Martins', '875', '', 'S�o Br�s', 'Bel�m', 'PA')
INSERT INTO CLIENTE VALUES('15393053843', 'Rosa Giovanna Baptista', '236955305', '1968-08-20', 1, 'PA', '1969-03-10', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('62388974', 'Rodovia Jos� Maria Melo, s/n', '187', '', 'Centro', 'V�rzea dos Espinhos', 'CE')
INSERT INTO CLIENTE VALUES('56785261708', 'Ruan Enzo Geraldo da Cunha', '170218090', '1989-07-22', 1, 'CE', '1989-10-23', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68900012', 'Rua Rio Juru�', '163', '', 'Central', 'Macap�', 'AP')
INSERT INTO CLIENTE VALUES('01809636000', 'Eduardo Francisco Almeida', '287574684', '1945-07-24', 1, 'AP', '1945-08-05', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('36202344', 'Rua Marechal Floriano Peixoto', '459', '', 'Pontilh�o', 'Barbacena', 'MG')
INSERT INTO CLIENTE VALUES('19721345075', 'Patr�cia Aparecida Almada', '151307052', '1979-05-12', 1, 'MG', '1980-04-25', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('78075210', 'Rua Um', '245', '', 'Recanto dos P�ssaros', 'Cuiab�', 'MT')
INSERT INTO CLIENTE VALUES('72518298940', 'Marcelo Vicente Kaique Ramos', '245851203', '2002-11-04', 1, 'MT', '2003-06-09', 1, 1, (SELECT @@IDENTITY))

INSERT INTO ENDERECO VALUES ('68911133', 'Avenida Rio Acre', '935', '', 'Fazendinha', 'Macap�', 'AP')
INSERT INTO CLIENTE VALUES('97626049705', 'D�bora Antonella Aline Pereira', '445522999', '1971-11-05', 1, 'AP', '1971-12-05', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68927206', 'Avenida Delorizano Monteiro', '821', '', 'Provedor I', 'Santana', 'AP')
INSERT INTO CLIENTE VALUES('07958171935', 'Renato Pedro Henrique Nathan Fernandes', '447910024', '1983-11-24', 1, 'AP', '1983-12-29', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('53160610', 'Rua Jardim �guas Claras', '240', '', '�guas Compridas', 'Olinda', 'PE')
INSERT INTO CLIENTE VALUES('97630238312', 'Patr�cia Alessandra Al�cia Oliveira', '305371988', '1982-05-10', 1, 'PE', '1982-12-22', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('25272293', 'Rua Carlos Drumond de Andrade', '254', '', 'Parada Ang�lica', 'Duque de Caxias', 'RJ')
INSERT INTO CLIENTE VALUES('89571712230', 'Ant�nia Renata Mariah Ribeiro', '243335702', '2005-08-04', 1, 'RJ', '2006-05-22', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('53040050', 'Rua Alfa', '399', '', 'Casa Caiada', 'Olinda', 'PE')
INSERT INTO CLIENTE VALUES('31367493404', 'Roberto M�rcio Bernardo Martins', '297853417', '1994-08-01', 1, 'PE', '1994-09-23', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('60543366', 'Rua Oscar Franca', '650', '', 'Bom Jardim', 'Fortaleza', 'CE')
INSERT INTO CLIENTE VALUES('87589795810', 'Marina Sophie Luna Monteiro', '301718933', '1947-04-05', 1, 'CE', '1947-07-13', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('53431670', 'Rua Alo�ndia', '650', '', 'Nossa Senhora do �', 'Paulista', 'PE')
INSERT INTO CLIENTE VALUES('13114422861', 'Pietra Renata Mariane da Paz', '487677857', '1986-06-24', 1, 'PE', '1986-09-21', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59090204', 'Rua Miramar', '398', '', 'Ponta Negra', 'Natal', 'RN')
INSERT INTO CLIENTE VALUES('13420516614', 'Evelyn Giovana Porto', '138232477', '1997-08-26', 1, 'RN', '1998-03-28', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68909886', 'Avenida dos Pardais', '901', '', 'Marabaixo', 'Macap�', 'AP')
INSERT INTO CLIENTE VALUES('82868071031', 'Elias Miguel Anderson Lopes', '492274927', '1993-01-09', 1, 'AP', '1993-12-17', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('88356017', 'Rua LI - 045', '512', '', 'Limeira', 'Brusque', 'SC')
INSERT INTO CLIENTE VALUES('91241188009', 'Gustavo Ian Tiago Silva', '134647439', '1965-12-09', 1, 'SC', '1966-09-03', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('39804560', 'Rua Antenor Barbosa', '356', '', 'S�o Crist�v�o', 'Te�filo Otoni', 'MG')
INSERT INTO CLIENTE VALUES('10689298803', 'Gustavo Theo Joaquim Souza', '384321501', '1998-06-05', 1, 'MG', '1999-05-17', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68906033', 'Avenida Anast�cio Gaud�ncio da Silva', '760', '', 'Goiabal', 'Macap�', 'AP')
INSERT INTO CLIENTE VALUES('38932815844', 'Louise Benedita das Neves', '137872823', '1959-08-26', 1, 'AP', '1960-04-08', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('49090240', 'Rua Professor Gileno de Freitas', '628', '', 'Bugio', 'Aracaju', 'SE')
INSERT INTO CLIENTE VALUES('01103164104', 'Aurora Amanda Drumond', '250422505', '1983-07-16', 1, 'SE', '1983-10-21', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('76965622', 'Rua Anita Garibaldi', '318', '', 'Teixeir�o', 'Cacoal', 'RO')
INSERT INTO CLIENTE VALUES('04510686617', 'Severino Marcos Vinicius Jos� Melo', '173003266', '2005-10-03', 1, 'RO', '2006-05-16', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59133131', 'Rua da Floresta', '190', '', 'Paju�ara', 'Natal', 'RN')
INSERT INTO CLIENTE VALUES('32807584594', 'Ana Vanessa Cl�udia Bernardes', '174308760', '1965-05-19', 1, 'RN', '1965-09-19', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('57080552', 'Rua Professor Pedro Teixeira de Vasconcelos', '246', '', 'Jardim Petr�polis', 'Macei�', 'AL')
INSERT INTO CLIENTE VALUES('74728393704', 'Cl�udio Bruno Henrique Cardoso', '495762775', '1986-05-02', 1, 'AL', '1986-07-27', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('88302350', 'Rua Ces�rio Chaves', '420', '', 'Fazenda', 'Itaja�', 'SC')
INSERT INTO CLIENTE VALUES('71903462878', 'Jaqueline Carla Assis', '119446200', '1958-08-29', 1, 'SC', '1958-09-21', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69312306', 'Avenida Nossa Senhora de Nazar�', '955', '', 'Asa Branca', 'Boa Vista', 'RR')
INSERT INTO CLIENTE VALUES('76662161306', 'Larissa Nicole Rafaela Peixoto', '111639803', '1992-10-13', 1, 'RR', '1993-02-14', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('77025436', 'Quadra ARSO 151 QI 28', '275', '', 'Plano Diretor Sul', 'Palmas', 'TO')
INSERT INTO CLIENTE VALUES('50973144092', 'Heloisa Alice da Rosa', '273682878', '1999-11-13', 1, 'TO', '2000-05-15', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59621050', 'Rua Orlando Dantas', '812', '', 'Barrocas', 'Mossor�', 'RN')
INSERT INTO CLIENTE VALUES('57337854544', 'Sarah Luana Apar�cio', '362363948', '1975-08-05', 1, 'RN', '1976-01-27', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('83410570', 'Rua Ponta Grossa', '586', '', 'Guaraituba', 'Colombo', 'PR')
INSERT INTO CLIENTE VALUES('68287064554', 'Matheus Anthony Figueiredo', '387184351', '2005-12-29', 1, 'PR', '2006-04-19', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('57081733', 'Rua Maria do Carmo de G�es', '122', '', 'Tabuleiro do Martins', 'Macei�', 'AL')
INSERT INTO CLIENTE VALUES('77008529872', 'Rodrigo Julio Luiz Farias', '295723993', '1973-12-04', 1, 'AL', '1974-05-13', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69912494', 'Rua Projetada 684', '233', '', 'Floresta Sul', 'Rio Branco', 'AC')
INSERT INTO CLIENTE VALUES('38518055938', 'Victor Cl�udio Matheus de Paula', '127786788', '1960-07-15', 1, 'AC', '1961-03-01', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('41195030', 'Rua S�nia Assis de Moura', '680', '', 'Barreiras', 'Salvador', 'BA')
INSERT INTO CLIENTE VALUES('69303216210', 'Giovanni Vicente Rocha', '113919566', '1956-12-24', 1, 'BA', '1957-02-03', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('29172721', 'Rua Manoel Aruanda', '487', '', 'Praia da Baleia', 'Serra', 'ES')
INSERT INTO CLIENTE VALUES('78047894919', 'Giovana Gabrielly Isabelly Brito', '196215912', '1959-11-22', 1, 'ES', '1960-04-13', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('29017163', 'Escadaria Vinte e Cinco de Maio', '718', '', 'Forte S�o Jo�o', 'Vit�ria', 'ES')
INSERT INTO CLIENTE VALUES('79452937351', 'Alexandre Thiago Martin Viana', '258660788', '1951-04-19', 1, 'ES', '1951-06-05', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('60533230', 'Rua 1096', '658', '', 'Conjunto Cear�', 'Fortaleza', 'CE')
INSERT INTO CLIENTE VALUES('50153193980', 'Esther Tatiane T�nia da Cruz', '128562390', '1962-03-29', 1, 'CE', '1962-06-13', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('57010242', 'Avenida Professor Loureiro', '836', '', 'Prado', 'Macei�', 'AL')
INSERT INTO CLIENTE VALUES('53779215268', 'S�nia Amanda da Mata', '379467860', '1971-05-27', 1, 'AL', '1971-10-14', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('64082586', 'Quadra 52', '545', '', 'Renascen�a', 'Teresina', 'PI')
INSERT INTO CLIENTE VALUES('39246370759', 'Yago Davi Anthony Rezende', '224297788', '1967-02-20', 1, 'PI', '1967-06-26', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('02832150', 'Rua Barivieri', '787', '', 'Parque S�o Lu�s', 'S�o Paulo', 'SP')
INSERT INTO CLIENTE VALUES('45576419111', 'Calebe Heitor Marcelo da Concei��o', '477145577', '1965-04-23', 1, 'SP', '1966-03-07', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('64018090', 'Rua Santa Ana', '778', '', 'Vermelha', 'Teresina', 'PI')
INSERT INTO CLIENTE VALUES('05180402832', 'Mariana Amanda Ant�nia Caldeira', '213520254', '1978-08-27', 1, 'PI', '1979-01-19', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59607233', 'Rua Jos� Galdino Cavalcante', '729', '', 'Aeroporto', 'Mossor�', 'RN')
INSERT INTO CLIENTE VALUES('85575321568', 'Murilo Yago Anthony Ferreira', '340100321', '1948-10-19', 1, 'RN', '1948-10-29', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('30666510', 'Rua Vereador Ant�nio Menezes', '282', '', 'Independ�ncia (Barreiro)', 'Belo Horizonte', 'MG')
INSERT INTO CLIENTE VALUES('55625522480', 'B�rbara Rita Almada', '475322551', '1968-10-07', 1, 'MG', '1969-08-08', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('68907206', 'Rua Milagres', '996', '', 'Renascer', 'Macap�', 'AP')
INSERT INTO CLIENTE VALUES('38923862509', 'Manuela Esther J�ssica Campos', '407910190', '1988-08-24', 1, 'AP', '1989-02-11', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('74955500', 'Avenida Turquesa', '253', '', 'Vila Oliveira', 'Aparecida de Goi�nia', 'GO')
INSERT INTO CLIENTE VALUES('95795633658', 'Emanuelly Valentina da Luz', '496098998', '1948-10-06', 1, 'GO', '1949-05-02', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('40100255', '2� Avenida Dom Manoel I', '592', '', 'Garcia', 'Salvador', 'BA')
INSERT INTO CLIENTE VALUES('81001505409', 'Kau� Manoel Osvaldo Santos', '100648903', '1958-07-14', 1, 'BA', '1958-12-19', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59122518', 'Avenida Doutor Jo�o Medeiros Filho', '861', '', 'Paju�ara', 'Natal', 'RN')
INSERT INTO CLIENTE VALUES('66547622665', 'Mariana Renata Alves', '133288870', '1970-09-15', 1, 'RN', '1970-09-17', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('78556062', 'Avenida dos Tarum�s', '113', '', 'Jardim Bot�nico', 'Sinop', 'MT')
INSERT INTO CLIENTE VALUES('04800236207', 'S�rgio Isaac Davi Peixoto', '476133713', '1981-11-07', 1, 'MT', '1982-05-02', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('78720081', 'Avenida Jo�o Ponce de Arruda', '725', '', 'Loteamento Cellos', 'Rondon�polis', 'MT')
INSERT INTO CLIENTE VALUES('01890615960', 'Gael Manoel Rodrigues', '316316672', '1988-12-21', 1, 'MT', '1989-02-23', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('40243450', 'Vila Rita', '891', '', 'Engenho Velho de Brotas', 'Salvador', 'BA')
INSERT INTO CLIENTE VALUES('77931637100', 'Marina Kamilly da Costa', '428881063', '1974-08-07', 1, 'BA', '1975-02-01', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69313578', 'Rua Soldado-Pol�cia Militar Django da Silva', '583', '', 'Caran�', 'Boa Vista', 'RR')
INSERT INTO CLIENTE VALUES('18226046300', 'Sueli Luciana Hadassa Costa', '502588871', '1981-06-06', 1, 'RR', '1981-09-23', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('69048480', 'Rua C 5', '748', '', 'Alvorada', 'Manaus', 'AM')
INSERT INTO CLIENTE VALUES('71339930315', 'Sebastiana Valentina Lav�nia Souza', '414968128', '1959-06-20', 1, 'AM', '1959-09-23', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('09273115', 'Travessa L�rios do Campo', '292', '', 'Jardim Alzira Franco', 'Santo Andr�', 'SP')
INSERT INTO CLIENTE VALUES('77033173067', 'Sandra Heloise Rocha', '490723949', '1957-07-15', 1, 'SP', '1957-12-18', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('23932470', 'Travessa Harmonia', '981', '', 'Campo Belo (Cunhambebe)', 'Angra dos Reis', 'RJ')
INSERT INTO CLIENTE VALUES('35538148700', 'Manoel Lu�s Noah Silveira', '255173143', '2005-10-25', 1, 'RJ', '2006-01-16', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('78557409', 'Estrada Jacinta', '306', '', 'Residencial Lisboa', 'Sinop', 'MT')
INSERT INTO CLIENTE VALUES('01940083206', 'Edson Ryan Moraes', '256123871', '1970-12-25', 1, 'MT', '1971-10-10', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('57070706', 'Quadra G', '748', '', 'Rio Novo', 'Macei�', 'AL')
INSERT INTO CLIENTE VALUES('92961444691', 'Levi Kau� Duarte', '230294248', '1996-02-20', 1, 'AL', '1996-03-07', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('24110566', 'Travessa Quatorze', '339', '', 'Engenhoca', 'Niter�i', 'RJ')
INSERT INTO CLIENTE VALUES('05825052755', 'Teresinha Marina Nascimento', '380742482', '1960-08-14', 1, 'RJ', '1960-12-23', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('59108303', '4� Travessa Maria Jos� Lira', '978', '', 'Potengi', 'Natal', 'RN')
INSERT INTO CLIENTE VALUES('83246448736', 'Agatha Gabrielly Ara�jo', '209652263', '1963-09-09', 1, 'RN', '1964-09-04', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('29198172', 'Rua Cec�lia Rosa Quirino', '564', '', 'Barra do Sahy', 'Aracruz', 'ES')
INSERT INTO CLIENTE VALUES('06558633701', 'Manuel Jos� Teixeira', '263617622', '1979-03-11', 1, 'ES', '1979-11-14', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('25961165', 'Rua Augusto do Amaral Peixoto', '203', '', 'Alto', 'Teres�polis', 'RJ')
INSERT INTO CLIENTE VALUES('55355074235', 'Ryan Sebasti�o Bryan dos Santos', '358010433', '1961-10-20', 1, 'RJ', '1962-02-06', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('74357051', 'Rua dos Buritis', '472', '', 'Jardins Lisboa', 'Goi�nia', 'GO')
INSERT INTO CLIENTE VALUES('25628484032', 'Eduardo C�sar Porto', '125299369', '1994-01-31', 1, 'GO', '1994-03-22', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('13803384', 'Rua Jos� Bueno de Moraes', '155', '', 'Recanto Di Verona', 'Mogi Mirim', 'SP')
INSERT INTO CLIENTE VALUES('50006288537', 'Luan Vicente Jorge Farias', '484301639', '2000-09-14', 1, 'SP', '2001-04-30', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('75805850', 'Rua Doutor Pl�nio Camargo', '524', '', 'Residencial Bandeirantes', 'Jata�', 'GO')
INSERT INTO CLIENTE VALUES('71337031496', 'Noah Roberto da Mata', '347270906', '1959-12-06', 1, 'GO', '1960-02-17', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('88064035', 'Servid�o Colibri', '951', '', 'Ribeir�o da Ilha', 'Florian�polis', 'SC')
INSERT INTO CLIENTE VALUES('77298487671', 'Eduarda Sarah Carvalho', '202411564', '1944-02-27', 1, 'SC', '1944-11-14', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('79075103', 'Rua Seiko Yonamine', '924', '', 'Parque do Sol', 'Campo Grande', 'MS')
INSERT INTO CLIENTE VALUES('42677389630', 'Ian Victor Kaique Vieira', '506051304', '1988-10-13', 1, 'MS', '1988-12-29', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('66816140', 'Travessa Ant�nio Tavernard', '879', '', 'Pratinha (Icoaraci)', 'Bel�m', 'PA')
INSERT INTO CLIENTE VALUES('72108098488', 'Fl�via S�nia Martins', '211732187', '1986-05-19', 1, 'PA', '1987-04-29', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('50100100', 'Rua Dom Vital', '992', '', 'Santo Amaro', 'Recife', 'PE')
INSERT INTO CLIENTE VALUES('67284564300', 'Gabriela Joana Ramos', '167231273', '1984-08-26', 1, 'PE', '1985-03-09', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('58068125', 'Rua Luiz Teodoro Pereira', '255', '', 'Gramame', 'Jo�o Pessoa', 'PB')
INSERT INTO CLIENTE VALUES('29246032853', 'Heloisa Elo� M�rcia Gon�alves', '420493517', '1956-12-26', 1, 'PB', '1957-09-17', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('49043640', 'Travessa A', '431', '', 'Santa Maria', 'Aracaju', 'SE')
INSERT INTO CLIENTE VALUES('52030593656', 'L�via Agatha Isabella Novaes', '176983478', '1983-08-07', 1, 'SE', '1983-10-18', 1, 2, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('99680973', 'Rua Principal, s/n', '406', '', 'Linha Barra Curta Baixa (Distrito)', 'Constantina', 'RS')
INSERT INTO CLIENTE VALUES('70267182589', 'Tatiane Stefany Arag�o', '474358537', '2004-05-18', 1, 'RS', '2005-03-08', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('65044451', 'Rua Amor', '607', '', 'Parque Nice Lob�o', 'S�o Lu�s', 'MA')
INSERT INTO CLIENTE VALUES('56031708400', 'Josefa Giovana da Costa', '107047214', '1988-07-07', 1, 'MA', '1989-03-10', 1, 1, (SELECT @@IDENTITY))


INSERT INTO ENDERECO VALUES ('78005130', 'Travessa Padre Maserati', '758', '', 'Centro Norte', 'Cuiab�', 'MT')
INSERT INTO CLIENTE VALUES('54594008640', 'Sabrina Rebeca Moraes', '124204399', '1968-07-25', 1, 'MT', '1969-06-13', 1, 1, (SELECT @@IDENTITY))
